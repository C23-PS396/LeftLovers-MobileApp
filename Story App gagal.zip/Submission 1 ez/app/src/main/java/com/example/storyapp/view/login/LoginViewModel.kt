package com.example.storyapp.view.login

import androidx.lifecycle.*
import com.example.storyapp.model.UserPreference
import com.example.storyapp.view.DataRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class LoginViewModel(private val dataRepository: DataRepository, private val userPreference: UserPreference): ViewModel() {
    fun login(email: String, password: String) = dataRepository.login(email, password)
    fun saveToken(token: String) {
        viewModelScope.launch(Dispatchers.IO) {
            userPreference.saveToken(token)
        }
    }
    fun checkIsLogin(): LiveData<Boolean> {
        return userPreference.isLogin().asLiveData()
    }

}
