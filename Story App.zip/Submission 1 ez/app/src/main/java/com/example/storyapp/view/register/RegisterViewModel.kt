package com.example.storyapp.view.register

import androidx.lifecycle.ViewModel
import com.example.storyapp.view.DataRepository


class RegisterViewModel(private val dataRepository: DataRepository) : ViewModel() {
    fun registerUser(name: String, email: String, password: String) =
            dataRepository.register(name, email, password)
}
