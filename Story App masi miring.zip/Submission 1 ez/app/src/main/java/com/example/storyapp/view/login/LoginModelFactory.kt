package com.example.storyapp.view.login



import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.storyapp.model.UserPreference
import com.example.storyapp.view.DataRepository
import com.example.storyapp.view.Injection

class LoginModelFactory private constructor(private val dataRepository: DataRepository, private val userPreference: UserPreference) :
    ViewModelProvider.NewInstanceFactory() {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(LoginViewModel::class.java)) {
            return LoginViewModel(dataRepository, userPreference) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
    companion object {
        @Volatile
        private var instance: LoginModelFactory? = null
        fun getInstance(
            userPreference: UserPreference
        ): LoginModelFactory =
            instance ?: synchronized(this) {
                instance ?: LoginModelFactory(
                    Injection.provideRepository(),
                    userPreference
                )
            }
    }
}