package com.example.storyapp.view

import android.content.ContentValues.TAG
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import com.example.storyapp.api.ApiService
import com.example.storyapp.model.LoginResponse
import com.example.storyapp.model.RegisterResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class DataRepository private constructor(
    private val apiService: ApiService,
) {
    private val resultRegister = MediatorLiveData<Result<RegisterResponse>>()
    private val resultLogin = MediatorLiveData<Result<LoginResponse>>()

    fun register(name: String, email: String, password: String): LiveData<Result<RegisterResponse>> {
        resultRegister.value = Result.Loading
        val client = apiService.postRegister(name, email, password)
        client.enqueue(object : Callback<RegisterResponse> {
            override fun onResponse(
                call: Call<RegisterResponse>,
                response: Response<RegisterResponse>
            ) {
                val responseBody = response.body()
                if (response.isSuccessful && responseBody != null) {
                    resultRegister.value = Result.Success(responseBody)
                } else {
                    resultRegister.value = Result.Error("gagal registrasi")
                    Log.e(TAG, "onFailure: gagal")
                }
            }

            override fun onFailure(call: Call<RegisterResponse>, t: Throwable) {
                resultRegister.value = Result.Error("gagal registrasi")
                Log.e(TAG, "onFailure: fail")
            }
        })
        return resultRegister
    }

    fun login(email: String, password: String): LiveData<Result<LoginResponse>>{
        resultLogin.value = Result.Loading
        val client = apiService.postLogin(email, password)
        client.enqueue(object : Callback<LoginResponse> {
            override fun onResponse(call: Call<LoginResponse>, response: Response<LoginResponse>) {
                val responseBody = response.body()
                if (response.isSuccessful && responseBody != null) {
                    resultLogin.value = Result.Success(responseBody)
                }else {
                    resultLogin.value = Result.Error("gagal login")
                    Log.e(TAG, "onFailure: gagal")
                }
            }
            override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                resultLogin.value = Result.Error("gagal login")
                Log.e(TAG, "onFailure: fail")
            }
        })
        return resultLogin
    }

    companion object {
        @Volatile
        private var instance: DataRepository? = null
        fun getInstance(
            apiService: ApiService,
        ): DataRepository =
            instance ?: synchronized(this) {
                instance ?: DataRepository(apiService)
            }.also { instance = it }
    }
}